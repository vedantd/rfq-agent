import { useRef, useState } from "react";

type IconName =
  | "activity"
  | "arrow"
  | "check"
  | "chevron"
  | "clock"
  | "cube"
  | "document"
  | "download"
  | "grid"
  | "inbox"
  | "layers"
  | "more"
  | "plus"
  | "search"
  | "shield"
  | "spark"
  | "upload"
  | "user";

const paths: Record<IconName, React.ReactNode> = {
  activity: <><path d="M3 12h4l2.3-6 4.2 12 2.2-6H21" /></>,
  arrow: <><path d="M5 12h14M13 6l6 6-6 6" /></>,
  check: <><path d="m5 12 4 4L19 6" /></>,
  chevron: <><path d="m9 18 6-6-6-6" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  cube: <><path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z" /><path d="m4.2 7.5 7.8 4.4 7.8-4.4M12 21v-9.1" /></>,
  document: <><path d="M6 3h8l4 4v14H6z" /><path d="M14 3v5h5M9 13h6M9 17h5" /></>,
  download: <><path d="M12 3v12m0 0 5-5m-5 5-5-5M5 21h14" /></>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
  inbox: <><path d="M4 5h16v14H4z" /><path d="m4 13 4-3h8l4 3M8 14h8" /></>,
  layers: <><path d="m12 3 9 5-9 5-9-5 9-5Z" /><path d="m3 12 9 5 9-5M3 16l9 5 9-5" /></>,
  more: <><circle cx="5" cy="12" r="1" fill="currentColor" /><circle cx="12" cy="12" r="1" fill="currentColor" /><circle cx="19" cy="12" r="1" fill="currentColor" /></>,
  plus: <><path d="M12 5v14M5 12h14" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m16 16 5 5" /></>,
  shield: <><path d="M12 3 20 6v5c0 5-3.4 8.3-8 10-4.6-1.7-8-5-8-10V6l8-3Z" /><path d="m8.5 12 2.2 2.2 4.8-5" /></>,
  spark: <><path d="m12 3 1.4 4.1L17.5 8.5l-4.1 1.4L12 14l-1.4-4.1-4.1-1.4 4.1-1.4L12 3ZM18.5 14l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2Z" /></>,
  upload: <><path d="M12 16V4m0 0L7 9m5-5 5 5M5 14v6h14v-6" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
};

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

const lineItems = [
  { line: "01", input: "304 SS sheet 16ga 4x8", match: "Stainless steel sheet", spec: "ASTM A240 · 304 · 0.0598 in", qty: "24 sheets", unit: "$138.40", total: "$3,321.60", confidence: 98, status: "Verified" },
  { line: "02", input: "A36 PL 1/4 60 x 120", match: "Carbon steel plate", spec: "ASTM A36 · 0.250 in", qty: "10 plates", unit: "$286.15", total: "$2,861.50", confidence: 96, status: "Verified" },
  { line: "03", input: "2in sched 40 pipe, 316L", match: "Stainless pipe", spec: "ASTM A312 · 316L · Sch 40", qty: "400 ft", unit: "$18.72", total: "$7,488.00", confidence: 87, status: "Review" },
  { line: "04", input: "Al angle 6061 2x2x.125", match: "Aluminum equal angle", spec: "ASTM B221 · 6061-T6", qty: "120 ft", unit: "$4.94", total: "$592.80", confidence: 72, status: "Question" },
];

const nav = [
  { label: "Overview", icon: "grid" as IconName },
  { label: "RFQ Inbox", icon: "inbox" as IconName, count: 8 },
  { label: "Catalog", icon: "cube" as IconName },
  { label: "Quotes", icon: "document" as IconName },
  { label: "Audit log", icon: "shield" as IconName },
];

function App() {
  const [activeNav, setActiveNav] = useState("RFQ Inbox");
  const [activeTab, setActiveTab] = useState("Line items");
  const [selectedLine, setSelectedLine] = useState("03");
  const [fileName, setFileName] = useState("RudCo_RFQ_1048.pdf");
  const fileInput = useRef<HTMLInputElement>(null);

  const handleFile = (file?: File) => {
    if (file) setFileName(file.name);
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><span /><span /><span /></div>
          <div className="brand-name">Forge<span>quote</span></div>
        </div>

        <nav className="primary-nav" aria-label="Main navigation">
          <div className="nav-label">Workspace</div>
          {nav.map((item) => (
            <button key={item.label} className={`nav-item ${activeNav === item.label ? "active" : ""}`} onClick={() => setActiveNav(item.label)}>
              <Icon name={item.icon} />
              <span>{item.label}</span>
              {item.count && <span className="nav-count">{item.count}</span>}
            </button>
          ))}
        </nav>

        <div className="sidebar-foot">
          <div className="security-card">
            <div className="security-icon"><Icon name="shield" size={17} /></div>
            <div>
              <strong>Block Convey AI</strong>
              <span>Audit trail is active</span>
            </div>
            <span className="live-dot" />
          </div>
          <div className="profile">
            <div className="avatar">MK</div>
            <div><strong>Marcus Kim</strong><span>Sales operations</span></div>
            <Icon name="more" />
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="breadcrumb"><span>RFQ Inbox</span><Icon name="chevron" size={14} /><strong>RFQ-1048</strong></div>
          <div className="top-actions">
            <div className="search-box"><Icon name="search" size={16} /><span>Search catalog</span><kbd>⌘ K</kbd></div>
            <button className="icon-button" aria-label="Activity"><Icon name="activity" /></button>
            <button className="primary-button"><Icon name="plus" size={16} />New RFQ</button>
          </div>
        </header>

        <div className="workspace">
          <section className="title-row">
            <div>
              <div className="eyebrow"><span className="status-pulse" />PROCESSING COMPLETE</div>
              <div className="page-title" role="heading" aria-level={1}>RFQ-1048 <span>Northline Fabrication</span></div>
              <div className="subtitle">Received via email · Jun 18, 2025 at 9:42 AM · 4 line items</div>
            </div>
            <div className="title-actions">
              <button className="secondary-button"><Icon name="download" size={16} />Export</button>
              <button className="primary-button">Review draft quote<Icon name="arrow" size={16} /></button>
            </div>
          </section>

          <section className="pipeline" aria-label="RFQ processing progress">
            {[
              ["Parse & normalize", "Completed in 4.2s", "check"],
              ["Catalog matching", "4 of 4 matched", "check"],
              ["Compliance", "3 verified · 1 review", "shield"],
              ["Price benchmark", "Within market range", "activity"],
              ["Quote ready", "Draft generated", "spark"],
            ].map(([title, sub, icon], index) => (
              <div className={`pipeline-step ${index === 4 ? "current" : ""}`} key={title}>
                <div className="step-icon"><Icon name={icon as IconName} size={16} /></div>
                <div><strong>{title}</strong><span>{sub}</span></div>
                {index < 4 && <div className="connector" />}
              </div>
            ))}
          </section>

          <div className="content-grid">
            <section className="work-panel">
              <div className="tabs">
                {["Line items", "Source document", "Activity"].map((tab) => (
                  <button className={activeTab === tab ? "active" : ""} onClick={() => setActiveTab(tab)} key={tab}>
                    {tab}{tab === "Line items" && <span>4</span>}
                  </button>
                ))}
                <button className="panel-menu" aria-label="More options"><Icon name="more" /></button>
              </div>

              {activeTab === "Line items" ? (
                <>
                  <div className="table-head table-grid">
                    <span>Original request</span><span>Normalized match & specification</span><span>Quantity</span><span>Quote</span><span>Confidence</span>
                  </div>
                  <div className="item-list">
                    {lineItems.map((item) => (
                      <button className={`item-row table-grid ${selectedLine === item.line ? "selected" : ""}`} key={item.line} onClick={() => setSelectedLine(item.line)}>
                        <div className="original-cell"><span className="line-number">{item.line}</span><div><strong>{item.input}</strong><span>Line {Number(item.line)}</span></div></div>
                        <div className="match-cell"><strong>{item.match}</strong><span>{item.spec}</span><em><Icon name="check" size={11} />Catalog matched</em></div>
                        <div className="quantity-cell"><strong>{item.qty}</strong><span>Requested</span></div>
                        <div className="quote-cell"><strong>{item.total}</strong><span>{item.unit} / unit</span></div>
                        <div className="confidence-cell">
                          <div className={`confidence ${item.confidence < 80 ? "low" : item.confidence < 90 ? "medium" : ""}`}>{item.confidence}%</div>
                          <span className={`item-status ${item.status.toLowerCase()}`}>{item.status}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                  <div className="table-footer">
                    <span><Icon name="spark" size={15} />Normalized via Nicrron Gateway</span>
                    <span>Last updated just now</span>
                  </div>
                </>
              ) : activeTab === "Source document" ? (
                <div className="document-preview">
                  <div className="file-card"><Icon name="document" size={30} /><div><strong>{fileName}</strong><span>PDF document · 2 pages</span></div><button className="secondary-button">Open document</button></div>
                  <div className="document-lines">{Array.from({ length: 8 }).map((_, i) => <span key={i} className={i === 2 || i === 5 ? "short" : ""} />)}</div>
                </div>
              ) : (
                <div className="activity-list">
                  {[
                    ["Draft quote generated", "Pricing and terms prepared for review", "Just now"],
                    ["Compliance check completed", "Country of origin flag on line 03", "12 sec ago"],
                    ["Catalog matching completed", "4 items matched against 18,400 SKUs", "18 sec ago"],
                    ["RFQ received", fileName, "32 sec ago"],
                  ].map(([title, detail, time]) => <div className="activity-row" key={title}><div className="activity-dot"><Icon name="check" size={13} /></div><div><strong>{title}</strong><span>{detail}</span></div><time>{time}</time></div>)}
                </div>
              )}
            </section>

            <aside className="right-panel">
              <div className="summary-card">
                <div className="card-heading"><div><span>Draft quote</span><strong>$14,263.90</strong></div><span className="draft-badge">DRAFT</span></div>
                <div className="summary-lines">
                  <div><span>Materials subtotal</span><strong>$14,263.90</strong></div>
                  <div><span>Freight estimate</span><strong>Calculated at checkout</strong></div>
                  <div><span>Lead time</span><strong>8–12 business days</strong></div>
                  <div><span>Valid until</span><strong>Jul 18, 2025</strong></div>
                </div>
                <div className="margin-box"><div><span>Estimated margin</span><strong>18.4%</strong></div><div className="margin-track"><span /></div><small>2.4% above your target</small></div>
                <button className="primary-button full">Review & send quote<Icon name="arrow" size={16} /></button>
                <button className="text-button">Edit pricing & terms</button>
              </div>

              <div className="review-card">
                <div className="card-title"><div><Icon name="spark" size={17} />Needs your attention</div><span>1</span></div>
                <div className="attention-content">
                  <div className="attention-head"><span className="amber-icon"><Icon name="clock" size={15} /></span><div><strong>Clarification recommended</strong><span>Line 04 · 72% confidence</span></div></div>
                  <p>The requested temper is not specified for the aluminum angle.</p>
                  <div className="question-box"><span>Suggested question</span><p>“Should we quote the aluminum angle in 6061-T6 temper?”</p></div>
                  <div className="attention-actions"><button className="secondary-button">Edit</button><button className="dark-button">Add to email</button></div>
                </div>
              </div>

              <div className="audit-card">
                <div className="audit-icon"><Icon name="shield" size={17} /></div>
                <div><strong>Fully auditable</strong><span>18 reasoning steps and sources logged</span></div>
                <button aria-label="View audit"><Icon name="chevron" size={16} /></button>
              </div>
            </aside>
          </div>

          <section className="upload-strip" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files[0]); }}>
            <input ref={fileInput} type="file" accept=".pdf,.csv,.xlsx,.xls,.eml" onChange={(e) => handleFile(e.target.files?.[0])} />
            <div className="upload-icon"><Icon name="upload" size={17} /></div>
            <div><strong>Have another RFQ?</strong><span>Drop a PDF, CSV, spreadsheet, or email here</span></div>
            <button className="secondary-button" onClick={() => fileInput.current?.click()}>Browse files</button>
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;
